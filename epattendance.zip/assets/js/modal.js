function showModal() {
  var modal = document.getElementById('myModal');
  if (modal) {
      modal.style.display = 'block';
  } else {
      console.error('Modal element not found.');
  }
}
