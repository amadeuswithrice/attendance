</div><!-- end of div.container-->

</div>
<footer class="bg-dark text-light text-center py-4">
    <div class="container">
        <img src="include/img/logo1.png" alt="Description of image" class="custom-image" />
        <p>&copy; 2024 All rights Reserved</p>
        
    </div><!-- end of div.container -->
</footer>


</body>

</html>