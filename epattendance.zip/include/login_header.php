<!DOCTYPE html>
<html lang="en">
<head>
  <title>Employee time Management</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="./assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="./assets/css/bootstrap.theme.min.css">
  
  <script src="./assets/js/jquery.min.js"></script>
  <script src="./assets/js/bootstrap.min.js"></script>
  <script src="./assets/js/custom.js"></script>
  <link href="//cdn.muicss.com/mui-0.9.12/css/mui.min.css" rel="stylesheet" type="text/css" />
    <script src="//cdn.muicss.com/mui-0.9.12/js/mui.min.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700|Oswald:400,500,600,700" rel="stylesheet">

</head>
<body>






<div class="main">