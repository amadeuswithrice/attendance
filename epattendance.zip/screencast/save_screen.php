<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "etms_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fullname = $_POST['fullname'];
    $imageData = $_POST['image'];

    // Prepare and bind parameters
    $stmt = $conn->prepare("INSERT INTO tbl_screencast (fullname, r_screen, filename) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $fullname, $imageData, $filename);

    // Set filename (you may want to generate a unique filename)
    $filename = "captured_image_" . date("Y-m-d_H-i-s") . ".png";

    // Execute the statement
    if ($stmt->execute() === TRUE) {
        echo "Image saved successfully.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close statement
    $stmt->close();
}

// Close connection
$conn->close();
?>
