<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Automatic Screen Capture</title>
    <!-- Include html2canvas library from CDN -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.min.js"></script>
</head>
<body>
  <div id="app">
    <screencapture></screencapture>
  </div>

  <!-- Import Vue.js library -->
  <script src="https://cdn.jsdelivr.net/npm/vue@2"></script>
  <!-- Import your Vue component -->
  <script src="vue/component.js"></script>
</body>
</html>
