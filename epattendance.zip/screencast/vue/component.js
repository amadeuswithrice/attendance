Vue.component('screencapture', {
    template: `
      <div>
        <h1>Automatic Screen Capture</h1>
        <img :src="capturedImageUrl" id="captured-image" />
      </div>
    `,
    data() {
      return {
        capturedImageUrl: '',
        activityTimeout: null
      };
    },
    mounted() {
      this.resetActivityTimeout();
      document.addEventListener('mousemove', this.resetActivityTimeout);
      document.addEventListener('keydown', this.resetActivityTimeout);
    },
    methods: {
      captureScreen() {
        html2canvas(document.body).then(canvas => {
          let capturedImage = canvas.toDataURL('image/png');
          let fullname = prompt('Please enter your full name:');
          if (!fullname) {
            alert('Full name is required.');
            return;
          }
          let formData = new FormData();
          formData.append('fullname', fullname);
          formData.append('image', capturedImage);
          fetch('/save_image', {
            method: 'POST',
            body: formData
          })
          .then(response => {
            if (!response.ok) {
              throw new Error('Failed to save image. Please try again later.');
            }
            return response.json();
          })
          .then(data => {
            alert(data.message);
          })
          .catch(error => {
            console.error('Error saving image:', error.message);
            alert(error.message);
          });
        }).catch(error => {
          console.error('Error capturing screen:', error.message);
          alert('Error capturing screen. Please try again.');
        });
      },
      resetActivityTimeout() {
        clearTimeout(this.activityTimeout);
        this.activityTimeout = setTimeout(this.captureScreen, 10000);
      }
    }
  });
  
  new Vue({
    el: '#app'
  });
  